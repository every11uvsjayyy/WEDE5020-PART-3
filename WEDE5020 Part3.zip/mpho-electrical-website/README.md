# Mpho Electrical Services Website

WED5020POE website project. This README covers **Part 3 (Enhancing Functionality and SEO)** first, followed by the archived Part 2 documentation.

**Live site:** `https://mpho-electrical.netlify.app` (replace with your real URL after deploying, see section 9)

## 1. Part 3 overview

| Requirement | Where it is implemented |
|---|---|
| Accordion | `services.html`: FAQ section (built from `FAQS` in `js/services-data.js`) |
| Tabs | `about.html`: Mission / Vision / Values (arrow keys supported) |
| Modal | `services.html`: "View details" opens a service dialog |
| Interactive map | `contact.html`: Leaflet + OpenStreetMap, service-area circle, marker and suburb tooltips |
| Animations / transitions | Scroll fade-in (IntersectionObserver), tab/accordion/modal keyframes, hover transitions, back-to-top button. All disabled for `prefers-reduced-motion` |
| Advanced DOM manipulation | Service cards, FAQ, back-to-top button, results, estimate and email output are created with `createElement` / `textContent` |
| Gallery with lightbox | `services.html`: click to open, Esc to close, arrow keys, focus trap, caption and counter |
| Dynamic content | `services.html` renders cards from the `SERVICES` array in `js/services-data.js` |
| Search / filter / sort | `services.html`: text search, category filter, name/price sort, live result count |
| Enquiry form | `enquiry.html`: validated, calculates an estimated cost and availability on the page |
| Contact form | `contact.html`: validated, builds an email to `info@mphoelectrical.co.za` using `mailto:` |

Note: the service data lives in a `.js` file instead of a `.json` file loaded with `fetch()`, so the site also works when `index.html` is opened directly from disk.

## 2. Part 3 changelog

### 24 October 2026 - Part 3

**A. Corrections (Part 2 review)**

The Part 2 lecturer feedback was not available when this was prepared, so the items below were found by reviewing the Part 2 files. **Add any specific lecturer comments here, with the file name and the reason for each change.**

| File | Change | Reason |
|---|---|---|
| All pages | Business name standardised to "Mpho Electrical Services". It was "Solutions" in the logo, footer and copyright on some pages and "Services" in titles and about text | Inconsistent branding |
| All pages | Footer "Quick Links" now list the same five pages everywhere (some pages were missing links) | Inconsistent navigation |
| All pages | Footer headings changed from `h3` to `h2` | Heading levels skipped from `h1` to `h3` |
| All pages | `lang` changed to `en-ZA`; phone links changed to `tel:+27123456789` | Language targeting and working dialling |
| All pages | `rel="noopener"` changed to `rel="noopener noreferrer"` on external links | Security |
| All pages | `<script>` now uses `defer` | Page speed |
| `services.html` | Gallery images given `width` and `height` attributes | Prevents layout shift |
| `services.html` | Six hard-coded cards replaced by JavaScript-rendered cards | Dynamic content requirement |
| `contact.html` | "Map placeholder" box replaced by a real Leaflet map | Interactive map requirement |
| `enquiry.html` | Form rebuilt: inline error messages replace one general message; added quantity, date, property type and urgency fields | Validation and enquiry requirements |
| `contact.html` | Contact form added (name, email, phone, message type, message) | Form requirement for both pages |
| `README.txt` | Replaced by `README.md` with this changelog | Part 3 instruction |
| `images/responsive/` | **Known issue:** the 480, 800 and 1200 px files are identical copies of the 384 px originals, so they give no real size savings. Replace them with properly resized versions when larger originals are available | Found during review |

**B. Functionality:** added `js/script.js` modules (navigation, scroll effects, tabs, services search/filter/sort, modal, accordion, lightbox, map, enquiry and contact forms) and `js/services-data.js`. Styles were added to the end of `css/style.css` under "PART 3".

**C. Forms and validation**

- HTML5: `required`, `minlength`/`maxlength`, `type="email"`, `type="tel"`, `type="number"` with `min`/`max`, `type="date"` with `min`/`max` (today to six months ahead).
- JavaScript: name (letters, spaces, apostrophes, hyphens; 2-60 characters), email format, South African phone number (`0XXXXXXXXX` or `+27XXXXXXXXX`, spaces and dashes allowed), message length (minimum 10), quantity (1-50), date range, required select.
- Errors appear next to each field (`aria-invalid`, `aria-describedby`), on `blur`, and clear as the user corrects them. The status message uses `aria-live`.
- `enquiry.html` estimate = starting price x quantity, +15% for a business property, +25% if urgent, shown as a range (up to +20%). Availability comes from the chosen service and date.
- `contact.html` uses `action="mailto:info@mphoelectrical.co.za"`. After validation, JavaScript opens an email with the subject and body filled in, plus an "Open email to send" button as a fallback.

**D. SEO**

- Unique `<title>` and meta description on every page, canonical URL, Open Graph and Twitter tags.
- One `h1` per page with logical `h2`/`h3` structure; descriptive alt text and image file names.
- JSON-LD `Electrician` (LocalBusiness) data for Johannesburg.
- Internal links between related pages in body text.
- `robots.txt`, `sitemap.xml`, `404.html`, `favicon.svg`.
- Speed: `defer` scripts, lazy-loaded gallery images with dimensions, no JavaScript frameworks.
- Security: `_headers` for Netlify (Content-Security-Policy, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy); user input written with `textContent` only; `noopener noreferrer` on external links.

## 3. Keyword research

| Keyword | Used on |
|---|---|
| electrician Johannesburg | Home title and hero, CTA |
| electrical repairs Johannesburg | Services, meta descriptions |
| electrical installation | Home, Services |
| fault finding | Services |
| lighting installation | Services, Home |
| electrical quote | Enquiry |
| certificate of compliance (CoC) | Services FAQ and service details |

## 4. Off-page SEO plan (complete after deployment)

- **Backlinks:** list the business on local directories (e.g. Yellow Pages SA, Hotfrog, Cylex) and ask suppliers or property agents to link to the site.
- **Social media:** create Facebook and Instagram business pages, post project photos with a link to `services.html`, and add the site to a WhatsApp Business profile.
- **Local SEO:** create a Google Business Profile (category: Electrician, service area: Johannesburg) with the same name, phone and address as the website, and collect customer reviews.

## 5. Testing

Checked in headless Chromium on a local server:

- Services: search, category filter, sorting, "no results" state, modal open/close with Esc, accordion, lightbox open/next/close.
- Enquiry: empty submit shows five errors; valid input shows an estimate (4 lighting points = R1,800 to R2,160); invalid phone rejected; `?service=` pre-selects the service.
- Contact: empty submit shows five errors. About: tabs switch.
- No horizontal scroll at 375 px on any page.
- **Not yet tested:** the Leaflet map (needs internet for the CDN and map tiles; a text fallback shows if it fails) and the email hand-off (depends on the visitor's email app). Test both on the live site and add screenshots.

## 6. How to run locally

Open the folder in VS Code and use Live Server, or run `python -m http.server` in the project folder.

## 7. Project structure

```text
mpho-electrical-website/
├── index.html, about.html, services.html, enquiry.html, contact.html, 404.html
├── robots.txt, sitemap.xml, _headers, README.md
├── css/style.css
├── js/script.js, js/services-data.js
└── images/ (favicon.svg, originals, responsive/)
```

## 8. Placeholder information

The phone number, email address, WhatsApp number, map location, opening hours and all prices are fictional placeholders for the academic project.

## 9. Deployment (Netlify)

1. Create a free account at netlify.com and choose **Add new site > Deploy manually**.
2. Drag the `mpho-electrical-website` folder into the upload area (or connect the GitHub repository).
3. Optionally rename the site under **Site configuration > Change site name**.
4. Replace `https://mpho-electrical.netlify.app` with your real address in all five HTML files (canonical, `og:url`, `og:image`, JSON-LD), `sitemap.xml`, `robots.txt` and this README.
5. Redeploy, then submit `sitemap.xml` to Google Search Console.

GitHub Pages also works, but it ignores `_headers`.

---

# Part 2 (archived documentation)

WED5020POE website project

## 1. Project Overview

This website was developed for Mpho Electrical Services as an academic web-development project. Part 2 focuses on CSS styling, desktop layout, responsive design, accessibility improvements, responsive images and testing across different screen sizes.

## 2. Pages

- index.html - Home page
- about.html - About the business
- services.html - Electrical services and work gallery
- enquiry.html - Enquiry/quotation form
- contact.html - Contact information and service area

## 3. Project Structure

```text
mpho-electrical-website/
│
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── README.txt
│
├── css/
│   └── style.css
│
├── js/
│   └── script.js
│
└── images/
    ├── original images
    └── responsive/
        ├── 480px image versions
        ├── 800px image versions
        └── 1200px image versions
```

## 4. How to Run the Website

Open `index.html` in a web browser, or open the project folder in VS Code and use the Live Server extension.

## 5. Part 2 CSS Implementation

### 5.1 External Stylesheet

A single external stylesheet named `css/style.css` is linked to all five HTML pages. This keeps the visual design consistent and reduces repeated CSS code.

### 5.2 CSS Reset and Base Styles

The stylesheet begins with a CSS reset that removes default browser margins and padding and applies `box-sizing: border-box` to all elements. Base styles define the website font, text colour, line height, background colour and responsive image behaviour.

### 5.3 CSS Variables

Reusable CSS custom properties are defined in `:root` for the main colours, borders, shadows, spacing and border radius. This makes the design easier to maintain and demonstrates reuse of CSS rules.

### 5.4 Typography

Typography uses `rem` and `clamp()` values for responsive headings and text. The design includes different heading levels, font weights, line heights and letter spacing. The `.eyebrow` class provides consistent small uppercase labels throughout the website.

### 5.5 Desktop Layout

CSS Grid is used for the main two-column hero, two-column content sections, service cards, forms and gallery. Flexbox is used for the navigation, button groups and mobile navigation.

The desktop service card layout uses three columns, while the six-service section also uses three columns. The gallery uses three columns on larger screens.

### 5.6 Visual Styling

The website uses:

- Background colours
- Text colours
- Borders
- Rounded corners
- Box shadows
- Hover effects
- Active states
- Focus states
- Button styling
- Card hover animations
- Responsive navigation

### 5.7 Pseudo-classes

The stylesheet uses `:hover`, `:focus`, `:focus-visible` and `:active` states for interactive elements. These states provide visual feedback when users interact with links, buttons and form controls.

### 5.8 Responsive Design

The website uses multiple responsive breakpoints:

- Large desktop/default: above 992px
- Tablet/smaller desktop: 992px and below
- Tablet/mobile: 800px and below
- Mobile: 600px and below
- Small mobile: 480px and below

At smaller widths, multi-column layouts change to two columns and then one column. The navigation changes from a horizontal desktop menu to a mobile menu controlled by JavaScript.

### 5.9 Relative Units

Relative units are used throughout the stylesheet, including:

- `rem` for typography and spacing
- `%` for container widths
- `vw` inside responsive `clamp()` calculations
- `fr` units for CSS Grid columns
- `min()` and `clamp()` for fluid sizing

This allows the website to adapt to different screen sizes instead of relying only on fixed pixel values.

### 5.10 Responsive Images

The Services page uses the `<picture>` element, `srcset` and `sizes` attributes. Three image resolutions are provided for the gallery:

- 480px for smaller mobile screens
- 800px for tablet-sized screens
- 1200px for larger screens

The browser can select a suitable image resource based on screen size and display conditions. Gallery images also use lazy loading to avoid loading all images before they are needed.

## 6. Accessibility Improvements

The following accessibility improvements were added in Part 2:

- A skip-to-content link was added to every page.
- Navigation has an accessible label.
- The mobile menu button has `aria-expanded` and `aria-controls` attributes.
- The current page is identified using `aria-current="page"`.
- Decorative icons use `aria-hidden="true"`.
- Form fields remain associated with their labels.
- Form feedback uses `aria-live` so that the message can be announced by assistive technology.
- Visible keyboard focus states were added.

## 7. Browser Developer Tools Testing

The website must be tested using browser Developer Tools and the device toolbar.

Recommended evidence sizes:

### Desktop

- 1920 × 1080
- 1366 × 768

Check the horizontal navigation, three-column cards, two-column sections, gallery and footer.

### Tablet

- 768 × 1024
- 820 × 1180

Check that grids reduce to two columns where appropriate and that text, buttons and images remain within the viewport.

### Mobile

- 390 × 844
- 375 × 667

Check that the navigation changes to the mobile menu, content becomes single-column, images fit the viewport and there is no horizontal scrolling.

## 8. Screenshot Evidence

Create a `screenshots` folder and add the screenshots taken from browser Developer Tools.

Recommended files:

```text
screenshots/
├── desktop-1920.png
├── desktop-1366.png
├── tablet-768.png
├── tablet-820.png
├── mobile-390.png
└── mobile-375.png
```

After adding the screenshots, include them in this README using Markdown image syntax, for example:

```md
![Desktop 1920px](screenshots/desktop-1920.png)
![Tablet 768px](screenshots/tablet-768.png)
![Mobile 390px](screenshots/mobile-390.png)
```

## 9. Part 2 Changelog

### 17 September 2026 - Part 2 CSS and Responsive Design

- Reworked the external `css/style.css` stylesheet while retaining the existing Mpho Electrical visual identity.
- Added a complete CSS reset and consistent base styles.
- Added reusable CSS custom properties for colours, shadows, borders, radius and container sizing.
- Improved typography using responsive `rem`, `clamp()` and `vw` values.
- Improved the desktop navigation and active-page styling.
- Added visible hover, focus and active states to navigation links and buttons.
- Added keyboard-accessible focus styling.
- Added a skip-to-content link to all pages.
- Added accessible navigation attributes including `aria-current`, `aria-expanded` and `aria-controls`.
- Improved the desktop hero layout using CSS Grid.
- Improved service cards using CSS Grid with reusable card styling.
- Improved the two-column content and enquiry form layouts.
- Added responsive breakpoints for desktop, tablet, mobile and small mobile screens.
- Changed multi-column layouts to two columns and then single-column layouts at smaller breakpoints.
- Improved the mobile navigation layout and spacing.
- Improved button sizing and stacking on mobile screens.
- Improved form styling, focus states and responsive textarea behaviour.
- Improved gallery styling and added responsive gallery columns.
- Added responsive image versions at 480px, 800px and 1200px widths.
- Added the `<picture>` element, `srcset` and `sizes` attributes to gallery images.
- Added lazy loading to gallery images.
- Added figure captions to the gallery to make the examples of work clearer.
- Added `aria-live` feedback support to the enquiry form message.
- Standardised the logo and footer branding across all pages.
- Added detailed documentation of responsive testing requirements and screenshot evidence.

## 10. Part 1 Feedback Corrections

The Part 2 version also provides a place to record the exact corrections made from the lecturer's Part 1 feedback. The following section should be edited further if the lecturer provided specific comments that are not already represented above.

- Review each Part 1 feedback comment.
- Apply the required correction to the relevant HTML, CSS or JavaScript file.
- Add the exact correction and its reason to the changelog above.
- Test the corrected page again before final submission.

## 11. Important Placeholder Information

The phone number, email address, WhatsApp number and business details are fictional placeholders for the academic project. Replace them with the final details required by the assignment/client if necessary.

## 12. Final Submission Checklist

Before submitting Part 2:

[ ] All five HTML pages load correctly.
[ ] All five pages link to `css/style.css`.
[ ] Navigation works on desktop and mobile.
[ ] The active page is clearly identified.
[ ] Desktop layout uses multiple columns where appropriate.
[ ] Tablet layout has been tested.
[ ] Mobile layout has been tested.
[ ] No horizontal scrolling occurs on mobile.
[ ] Images remain inside the viewport.
[ ] `srcset`, `sizes` and `<picture>` are working on the gallery.
[ ] Hover, focus and active states have been tested.
[ ] Enquiry form validation still works.
[ ] Developer Tools screenshots have been taken.
[ ] Screenshots have been added to the README.
[ ] Part 1 feedback corrections have been implemented.
[ ] Every important change has been recorded in the changelog.
[ ] All links and pages have been checked before submission.
