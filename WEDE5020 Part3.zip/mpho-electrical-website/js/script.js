/* Mpho Electrical Services - Part 3 JavaScript
   Sections: helpers, navigation, scroll effects, tabs, services (dynamic content),
   accordion, modal, lightbox, map, forms and validation. Each feature only runs on
   pages that contain its elements. */
"use strict";

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const money = n => "R" + Number(n).toLocaleString("en-ZA");

/* ---------- Navigation (Part 2) ---------- */
function initNav() {
    const btn = $(".menu-toggle"), nav = $(".nav-links");
    if (!btn || !nav) return;
    btn.addEventListener("click", () => {
        const open = nav.classList.toggle("open");
        btn.setAttribute("aria-expanded", String(open));
        btn.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
    });
    $$("a", nav).forEach(a => a.addEventListener("click", () => {
        nav.classList.remove("open");
        btn.setAttribute("aria-expanded", "false");
    }));
}

/* ---------- Scroll effects: fade-in, back-to-top, footer year ---------- */
function initScrollEffects() {
    const year = $("#year");
    if (year) year.textContent = new Date().getFullYear();

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const targets = $$(".reveal");
    if ("IntersectionObserver" in window && !reduce) {
        document.documentElement.classList.add("js-reveal");
        const io = new IntersectionObserver((entries, obs) => {
            entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add("visible"); obs.unobserve(e.target); } });
        }, { threshold: 0.12 });
        targets.forEach(t => io.observe(t));
    } else {
        targets.forEach(t => t.classList.add("visible"));
    }

    // Back-to-top button created with DOM manipulation
    const top = document.createElement("button");
    top.type = "button";
    top.className = "back-to-top";
    top.setAttribute("aria-label", "Back to top");
    top.textContent = "↑";
    document.body.appendChild(top);
    top.addEventListener("click", () => window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" }));
    window.addEventListener("scroll", () => top.classList.toggle("show", window.scrollY > 500), { passive: true });
}

/* ---------- Tabs (about.html) ---------- */
function initTabs() {
    $$("[data-tabs]").forEach(group => {
        const tabs = $$('[role="tab"]', group);
        const select = tab => {
            tabs.forEach(t => {
                const on = t === tab;
                t.setAttribute("aria-selected", String(on));
                t.tabIndex = on ? 0 : -1;
                $("#" + t.getAttribute("aria-controls")).hidden = !on;
            });
            tab.focus();
        };
        tabs.forEach((tab, i) => {
            tab.addEventListener("click", () => select(tab));
            tab.addEventListener("keydown", e => {
                if (e.key === "ArrowRight") select(tabs[(i + 1) % tabs.length]);
                if (e.key === "ArrowLeft") select(tabs[(i - 1 + tabs.length) % tabs.length]);
            });
        });
    });
}

/* ---------- Services page: dynamic content, search, filter, sort ---------- */
function initServices() {
    const list = $("#serviceList");
    if (!list || typeof SERVICES === "undefined") return;
    const search = $("#serviceSearch"), cat = $("#serviceCategory"), sort = $("#serviceSort");
    const count = $("#resultCount"), none = $("#noResults");

    [...new Set(SERVICES.map(s => s.category))].sort().forEach(c => {
        const o = document.createElement("option");
        o.value = c; o.textContent = c; cat.appendChild(o);
    });

    function render() {
        const q = search.value.trim().toLowerCase();
        let items = SERVICES.filter(s =>
            (cat.value === "all" || s.category === cat.value) &&
            (!q || (s.name + " " + s.summary + " " + s.category).toLowerCase().includes(q)));
        const [key, dir] = sort.value.split("-");
        items.sort((a, b) => {
            const r = key === "price" ? a.from - b.from : a.name.localeCompare(b.name);
            return dir === "desc" ? -r : r;
        });

        list.textContent = "";
        items.forEach(s => {
            const card = document.createElement("article");
            card.className = "card visible";
            const icon = document.createElement("div");
            icon.className = "icon"; icon.setAttribute("aria-hidden", "true"); icon.textContent = s.icon;
            const h = document.createElement("h3"); h.textContent = s.name;
            const p = document.createElement("p"); p.textContent = s.summary;
            const price = document.createElement("p");
            price.className = "price"; price.textContent = "From " + money(s.from) + " " + s.unit;
            const b = document.createElement("button");
            b.type = "button"; b.className = "link-button"; b.textContent = "View details →";
            b.setAttribute("aria-label", "View details for " + s.name);
            b.addEventListener("click", () => openModal(s, b));
            card.append(icon, h, p, price, b);
            list.appendChild(card);
        });
        count.textContent = items.length + (items.length === 1 ? " service shown" : " services shown");
        none.hidden = items.length > 0;
    }

    [search, cat, sort].forEach(el => el.addEventListener("input", render));
    $("#serviceControls").addEventListener("submit", e => e.preventDefault());
    $("#clearFilters").addEventListener("click", () => { search.value = ""; cat.value = "all"; render(); search.focus(); });
    render();
}

/* ---------- Accessible dialog helper (modal + lightbox) ---------- */
let lastFocus = null;
function showDialog(el, trigger) {
    lastFocus = trigger || document.activeElement;
    el.hidden = false;
    document.body.classList.add("no-scroll");
    const first = $("[data-close]", el) || el;
    first.focus();
}
function hideDialog(el) {
    el.hidden = true;
    document.body.classList.remove("no-scroll");
    if (lastFocus) lastFocus.focus();
}
function trapFocus(e, el) {
    if (e.key !== "Tab") return;
    const f = $$("button, a[href], input, select, textarea", el).filter(x => !x.disabled && x.offsetParent !== null);
    if (!f.length) return;
    const a = f[0], z = f[f.length - 1];
    if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
    else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
}

/* ---------- Service details modal ---------- */
function openModal(s, trigger) {
    const m = $("#serviceModal");
    $("#modalIcon").textContent = s.icon;
    $("#modalTitle").textContent = s.name;
    $("#modalText").textContent = s.details;
    $("#modalPrice").textContent = money(s.from) + " " + s.unit;
    $("#modalAvail").textContent = s.availability;
    $("#modalLink").href = "enquiry.html?service=" + encodeURIComponent(s.id);
    showDialog(m, trigger);
}
function initModal() {
    const m = $("#serviceModal");
    if (!m) return;
    m.addEventListener("click", e => { if (e.target === m || e.target.hasAttribute("data-close")) hideDialog(m); });
    document.addEventListener("keydown", e => {
        if (m.hidden) return;
        if (e.key === "Escape") hideDialog(m);
        trapFocus(e, m);
    });
}

/* ---------- FAQ accordion ---------- */
function initAccordion() {
    const wrap = $("#faqList");
    if (!wrap || typeof FAQS === "undefined") return;
    FAQS.forEach((f, i) => {
        const item = document.createElement("div");
        item.className = "acc-item";
        const h = document.createElement("h3");
        const btn = document.createElement("button");
        btn.type = "button"; btn.className = "acc-btn";
        btn.id = "acc-btn-" + i; btn.setAttribute("aria-expanded", "false"); btn.setAttribute("aria-controls", "acc-panel-" + i);
        btn.textContent = f.q;
        h.appendChild(btn);
        const panel = document.createElement("div");
        panel.className = "acc-panel"; panel.id = "acc-panel-" + i; panel.hidden = true;
        panel.setAttribute("role", "region"); panel.setAttribute("aria-labelledby", btn.id);
        const p = document.createElement("p"); p.textContent = f.a; panel.appendChild(p);
        btn.addEventListener("click", () => {
            const open = btn.getAttribute("aria-expanded") === "true";
            $$(".acc-btn", wrap).forEach(b => { b.setAttribute("aria-expanded", "false"); $("#" + b.getAttribute("aria-controls")).hidden = true; });
            if (!open) { btn.setAttribute("aria-expanded", "true"); panel.hidden = false; }
        });
        item.append(h, panel);
        wrap.appendChild(item);
    });
}

/* ---------- Gallery lightbox ---------- */
function initLightbox() {
    const lb = $("#lightbox");
    if (!lb) return;
    const triggers = $$(".lightbox-trigger");
    const img = $("#lbImage"), cap = $("#lbCaption");
    let index = 0;
    const show = i => {
        index = (i + triggers.length) % triggers.length;
        const t = triggers[index];
        img.src = t.dataset.full;
        img.alt = $("img", t).alt;
        cap.textContent = t.dataset.caption + " (" + (index + 1) + " of " + triggers.length + ")";
    };
    triggers.forEach((t, i) => t.addEventListener("click", () => { show(i); showDialog(lb, t); }));
    $(".lb-prev", lb).addEventListener("click", () => show(index - 1));
    $(".lb-next", lb).addEventListener("click", () => show(index + 1));
    lb.addEventListener("click", e => { if (e.target === lb || e.target.hasAttribute("data-close")) hideDialog(lb); });
    document.addEventListener("keydown", e => {
        if (lb.hidden) return;
        if (e.key === "Escape") hideDialog(lb);
        if (e.key === "ArrowLeft") show(index - 1);
        if (e.key === "ArrowRight") show(index + 1);
        trapFocus(e, lb);
    });
}

/* ---------- Leaflet map (contact.html) ---------- */
function initMap() {
    const el = $("#map");
    if (!el) return;
    if (typeof L === "undefined") {
        el.textContent = "The map could not be loaded. We serve Johannesburg and surrounding areas.";
        el.classList.add("map-fallback");
        return;
    }
    const base = [-26.2041, 28.0473]; // Johannesburg CBD (placeholder base)
    const map = L.map(el, { scrollWheelZoom: false }).setView(base, 10);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 18, attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);
    L.circle(base, { radius: 25000, color: "#d9a600", fillColor: "#ffc400", fillOpacity: 0.15 }).addTo(map);
    const marker = L.marker(base).addTo(map);
    const pop = document.createElement("div");
    const b = document.createElement("strong"); b.textContent = "Mpho Electrical Services";
    pop.append(b, document.createElement("br"), document.createTextNode("Serving Johannesburg and surrounds"));
    marker.bindPopup(pop);
    [["Sandton", -26.1076, 28.0567], ["Soweto", -26.2485, 27.8540], ["Randburg", -26.0936, 28.0064], ["Roodepoort", -26.1625, 27.8725]]
        .forEach(([n, lat, lng]) => L.circleMarker([lat, lng], { radius: 6, color: "#0b2d52", fillOpacity: 0.8 }).addTo(map).bindTooltip(n));
}

/* ---------- Form validation helpers ---------- */
const RULES = {
    name: v => /^\p{L}[\p{L}\s'.-]{1,59}$/u.test(v) || "Enter your full name using letters only (2 to 60 characters).",
    email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) || "Enter a valid email address, e.g. name@example.com.",
    // South African numbers: 0XX XXX XXXX or +27 XX XXX XXXX
    phone: v => /^(\+27|0)[1-9][0-9]{8}$/.test(v.replace(/[\s()-]/g, "")) || "Enter a valid South African number, e.g. 082 123 4567 or +27 82 123 4567.",
    message: v => v.length >= 10 || "Please enter at least 10 characters.",
};
function fieldError(input, msg) {
    const err = document.getElementById(input.id + "-error");
    if (err) err.textContent = msg || "";
    input.classList.toggle("invalid", Boolean(msg));
    input.setAttribute("aria-invalid", msg ? "true" : "false");
    if (err) input.setAttribute("aria-describedby", err.id);
    return !msg;
}
function checkField(input, rule) {
    const v = input.value.trim();
    if (!v) return fieldError(input, "This field is required.");
    if (rule) { const r = rule(v); if (r !== true) return fieldError(input, r); }
    return fieldError(input, "");
}
function liveValidate(pairs) {
    pairs.forEach(([input, rule]) => {
        input.addEventListener("blur", () => checkField(input, rule));
        input.addEventListener("input", () => { if (input.classList.contains("invalid")) checkField(input, rule); });
    });
}
function counter(textarea, out) {
    const upd = () => { out.textContent = textarea.value.length; };
    textarea.addEventListener("input", upd); upd();
}

/* ---------- Enquiry form: validate, then calculate estimate ---------- */
function initEnquiry() {
    const form = $("#enquiryForm");
    if (!form || typeof SERVICES === "undefined") return;
    const f = id => $("#" + id);
    const select = f("service"), qty = f("quantity"), date = f("date"), out = f("formMessage");

    SERVICES.forEach(s => { const o = document.createElement("option"); o.value = s.id; o.textContent = s.name; select.appendChild(o); });
    const pre = new URLSearchParams(location.search).get("service");
    if (pre && SERVICES.some(s => s.id === pre)) select.value = pre;

    // Date: today or later, within 6 months
    const iso = d => d.toISOString().slice(0, 10);
    const today = new Date(); const max = new Date(); max.setMonth(max.getMonth() + 6);
    date.min = iso(today); date.max = iso(max);

    const syncUnit = () => {
        const s = SERVICES.find(x => x.id === select.value);
        f("quantityLabel").textContent = (s ? "Quantity (" + s.unit + ") *" : "Quantity *");
    };
    select.addEventListener("change", syncUnit); syncUnit();
    counter(f("message"), f("charCount"));

    const rules = [[f("name"), RULES.name], [f("email"), RULES.email], [f("phone"), RULES.phone], [f("message"), RULES.message]];
    liveValidate(rules);

    form.addEventListener("submit", e => {
        e.preventDefault();
        let ok = rules.map(([i, r]) => checkField(i, r)).every(Boolean);
        ok = fieldError(select, select.value ? "" : "Please select a service.") && ok;
        const n = Number(qty.value);
        ok = fieldError(qty, Number.isInteger(n) && n >= 1 && n <= 50 ? "" : "Enter a whole number from 1 to 50.") && ok;
        let dErr = "";
        if (!date.value) dErr = "Please choose a preferred date.";
        else if (date.value < date.min) dErr = "The date cannot be in the past.";
        else if (date.value > date.max) dErr = "Please choose a date within the next 6 months.";
        ok = fieldError(date, dErr) && ok;

        out.className = "form-message";
        if (!ok) {
            out.classList.add("is-error");
            out.textContent = "Please correct the highlighted fields and try again.";
            const bad = $(".invalid", form); if (bad) bad.focus();
            return;
        }

        const s = SERVICES.find(x => x.id === select.value);
        const business = form.elements.property.value === "business";
        const urgent = f("urgent").checked;
        let total = s.from * n;
        if (business) total *= 1.15;
        if (urgent) total *= 1.25;
        const low = Math.round(total / 10) * 10, high = Math.round(total * 1.2 / 10) * 10;
        const when = new Date(date.value + "T00:00").toLocaleDateString("en-ZA", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
        const day = new Date(date.value + "T00:00").getDay();
        const weekend = day === 0 || day === 6;

        out.textContent = "";
        out.classList.add("is-success");
        const h = document.createElement("h3"); h.textContent = "Thank you, " + f("name").value.trim().split(" ")[0] + "!";
        const p1 = document.createElement("p"); p1.textContent = "Estimated cost for " + n + " × " + s.name + ": " + money(low) + " to " + money(high) + ".";
        const p2 = document.createElement("p");
        p2.textContent = "Availability: " + (urgent ? "same-day attendance is possible, subject to confirmation" : s.availability.toLowerCase()) + ". " +
            (weekend ? "Your chosen date (" + when + ") is a weekend, so we will confirm if we can attend." : "We can aim for " + when + ".");
        const p3 = document.createElement("p"); p3.className = "hint";
        p3.textContent = "This is an estimate only. We will contact you on " + f("phone").value.trim() + " to confirm a final quote.";
        out.append(h, p1, p2, p3);
        out.scrollIntoView({ behavior: "smooth", block: "nearest" });
        out.setAttribute("tabindex", "-1"); out.focus({ preventScroll: true });
    });
}

/* ---------- Contact form: validate, then build mailto link ---------- */
function initContact() {
    const form = $("#contactForm");
    if (!form) return;
    const f = id => $("#" + id);
    const type = f("c-type"), out = f("contactMessage");
    counter(f("c-message"), f("c-charCount"));
    const rules = [[f("c-name"), RULES.name], [f("c-email"), RULES.email], [f("c-phone"), RULES.phone], [f("c-message"), RULES.message]];
    liveValidate(rules);

    form.addEventListener("submit", e => {
        e.preventDefault();
        let ok = rules.map(([i, r]) => checkField(i, r)).every(Boolean);
        ok = fieldError(type, type.value ? "" : "Please choose a message type.") && ok;
        out.className = "form-message";
        if (!ok) {
            out.classList.add("is-error");
            out.textContent = "Please correct the highlighted fields and try again.";
            const bad = $(".invalid", form); if (bad) bad.focus();
            return;
        }
        const to = form.getAttribute("action").replace("mailto:", "");
        const subject = "Website message: " + type.value + " - " + f("c-name").value.trim();
        const body = [
            "Name: " + f("c-name").value.trim(),
            "Email: " + f("c-email").value.trim(),
            "Phone: " + f("c-phone").value.trim(),
            "Message type: " + type.value,
            "",
            f("c-message").value.trim()
        ].join("\n");
        const href = "mailto:" + to + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);

        out.classList.add("is-success");
        out.textContent = "";
        const p = document.createElement("p");
        p.textContent = "Your message is ready. Your email app should open now. If it does not, use the button below.";
        const a = document.createElement("a");
        a.className = "btn btn-primary"; a.href = href; a.textContent = "Open email to send";
        out.append(p, a);
        window.location.href = href;
    });
}

document.addEventListener("DOMContentLoaded", () => {
    initNav(); initScrollEffects(); initTabs(); initServices(); initModal();
    initAccordion(); initLightbox(); initMap(); initEnquiry(); initContact();
});
