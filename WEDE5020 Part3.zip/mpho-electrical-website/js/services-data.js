/* Service catalogue used by services.html (dynamic content) and enquiry.html (price estimate).
   Prices are fictional placeholders in South African rand (ZAR). */
const SERVICES = [
  { id: "installation", name: "Electrical Installation", category: "Installation", icon: "🔌",
    summary: "Installation solutions for homes, offices and small businesses.",
    details: "New plug points, sub-boards, geyser and stove circuits, and full wiring for extensions. Work is done to SANS 10142-1 and a Certificate of Compliance can be issued.",
    from: 850, unit: "per point / circuit", availability: "Within 3-5 working days" },
  { id: "repairs", name: "Electrical Repairs", category: "Repairs", icon: "🔧",
    summary: "Assistance with electrical faults, damaged components and repair requirements.",
    details: "Replacement of damaged switches, sockets, breakers and isolators, plus repair of tripping circuits and burnt-out fittings.",
    from: 550, unit: "per call-out", availability: "Same day or next day" },
  { id: "fault-finding", name: "Fault Finding", category: "Repairs", icon: "🔎",
    summary: "Systematic identification of electrical problems and likely causes.",
    details: "Testing with a multimeter and insulation tester to trace tripping, power loss, earth leakage and overheating problems. You receive a written summary of the fault.",
    from: 650, unit: "per hour", availability: "Same day or next day" },
  { id: "lighting", name: "Lighting Installation", category: "Lighting", icon: "💡",
    summary: "Indoor and outdoor lighting installation and improvement solutions.",
    details: "LED downlights, garden and security lighting, motion sensors and dimmer circuits, installed neatly and safely.",
    from: 450, unit: "per light point", availability: "Within 3-5 working days" },
  { id: "maintenance", name: "Maintenance", category: "Maintenance", icon: "🛠️",
    summary: "Routine electrical maintenance to help keep systems operating reliably.",
    details: "Inspection of distribution boards, earth leakage protection, tightening of connections and a safety check for landlords and small businesses.",
    from: 750, unit: "per inspection", availability: "Book 1 week ahead" },
  { id: "upgrades", name: "Electrical Upgrades", category: "Installation", icon: "⚙️",
    summary: "Upgrade existing electrical systems to suit changing customer requirements.",
    details: "Distribution board upgrades, added capacity for solar or inverter readiness, and replacement of old wiring.",
    from: 1500, unit: "per upgrade", availability: "Book 1-2 weeks ahead" }
];

const FAQS = [
  { q: "Do you issue a Certificate of Compliance (CoC)?", a: "Yes. For installation and upgrade work we can issue an electrical Certificate of Compliance, which is often needed when selling or renting a property." },
  { q: "Which areas do you serve?", a: "We serve Johannesburg and surrounding communities. Contact us to confirm availability in your suburb." },
  { q: "How quickly can you attend a fault?", a: "Repairs and fault finding are usually handled the same or the next working day, depending on the schedule." },
  { q: "Are your quotes free?", a: "Yes. Use the enquiry form for an estimated cost. A final quote is confirmed after we understand the job." },
  { q: "How do I pay?", a: "We accept EFT and card payments. A deposit may be requested for larger installation work." }
];
